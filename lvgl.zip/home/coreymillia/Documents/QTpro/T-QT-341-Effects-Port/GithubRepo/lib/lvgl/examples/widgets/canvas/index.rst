
Drawing on the Canvas and rotate
""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/canvas/lv_example_canvas_1
  :language: c

Transparent Canvas with chroma keying
""""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/canvas/lv_example_canvas_2
  :language: c

