```eval_rst
.. include:: /header.rst
:github_url: |github_link_base|/get-started/os/freertos.md
```
# FreeRTOS

TODO