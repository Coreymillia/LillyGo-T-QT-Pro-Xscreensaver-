```eval_rst
.. include:: /header.rst
:github_url: |github_link_base|/overview/renderers/arm-2d.md
```
# ARM-2D GPU

TODO

