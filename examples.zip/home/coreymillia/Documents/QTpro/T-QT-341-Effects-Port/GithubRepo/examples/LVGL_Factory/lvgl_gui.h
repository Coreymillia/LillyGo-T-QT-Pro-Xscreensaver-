#pragma once

void gui_init(void);
void gui_switch_page(uint8_t num);